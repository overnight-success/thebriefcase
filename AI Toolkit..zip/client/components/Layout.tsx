import { Link, useLocation } from "react-router-dom";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="min-h-screen bg-brand-red">
      {/* Top Navigation Bar */}
      <div className="bg-brand-black mb-3 py-9 pb-7">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-center">
            {/* Navigation Buttons */}
            <div className="flex items-center">
              <Link
                to="/ai-toolkit"
                className={`px-4 py-2 text-sm font-bold rounded-md mx-3 ${
                  isActive("/ai-toolkit")
                    ? "bg-brand-red text-white"
                    : "bg-transparent text-white border border-white hover:bg-white hover:text-brand-black"
                }`}
              >
                🤖 AI TOOLKIT
              </Link>
              <Link
                to="/upgrade"
                className={`px-2 py-2 text-sm font-bold rounded-md mx-3 ${
                  isActive("/upgrade")
                    ? "bg-white text-brand-red"
                    : "bg-brand-red text-white hover:bg-white hover:text-brand-red"
                }`}
              >
                ⬆️ UPGRADE
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      {children}
    </div>
  );
}
