import Layout from "@/components/Layout";

export default function Index() {
  return (
    <Layout>
      <div className="container mx-auto px-3 sm:px-6 py-4 sm:py-8">
        {/* Dashboard Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 sm:mb-8 space-y-4 sm:space-y-0">
          <div className="flex items-center">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-brand-black rounded-lg flex items-center justify-center mr-3 sm:mr-4">
              <span className="text-white text-lg sm:text-xl">⚡</span>
            </div>
            <div>
              <h1 className="text-brand-black text-2xl sm:text-3xl font-black tracking-wide">
                ADMIN DASHBOARD
              </h1>
              <p className="text-brand-black text-xs sm:text-sm opacity-70">
                Overnight Success Internal Panel
              </p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-3">
            <span className="bg-green-500 text-white px-3 py-1 text-xs font-bold rounded-full self-start sm:self-auto">
              ONLINE
            </span>
            <span className="text-brand-black text-xs sm:text-sm">
              Last updated: {new Date().toLocaleTimeString()}
            </span>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <div className="bg-brand-black rounded-xl p-4 sm:p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-gray-400 text-sm">Total Users</span>
              <span className="text-green-400 text-lg">👥</span>
            </div>
            <div className="text-white text-2xl font-bold mb-1">2,847</div>
            <div className="text-green-400 text-sm">↗ +12% this week</div>
          </div>

          <div className="bg-brand-black rounded-xl p-4 sm:p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-gray-400 text-sm">Active Sessions</span>
              <span className="text-blue-400 text-lg">🔥</span>
            </div>
            <div className="text-white text-xl sm:text-2xl font-bold mb-1">
              143
            </div>
            <div className="text-blue-400 text-sm">Live now</div>
          </div>

          <div className="bg-brand-black rounded-xl p-4 sm:p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-gray-400 text-sm">Tool Usage</span>
              <span className="text-purple-400 text-lg">🤖</span>
            </div>
            <div className="text-white text-xl sm:text-2xl font-bold mb-1">
              15.2K
            </div>
            <div className="text-purple-400 text-sm">↗ +8% today</div>
          </div>

          <div className="bg-brand-black rounded-xl p-4 sm:p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-gray-400 text-sm">Revenue</span>
              <span className="text-yellow-400 text-lg">💰</span>
            </div>
            <div className="text-white text-xl sm:text-2xl font-bold mb-1">
              $24.8K
            </div>
            <div className="text-yellow-400 text-sm">↗ +18% this month</div>
          </div>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          {/* Recent Activity */}
          <div className="lg:col-span-2 order-2 lg:order-1">
            <div className="bg-brand-black rounded-xl p-4 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 sm:mb-6 space-y-2 sm:space-y-0">
                <h3 className="text-white text-lg font-bold">
                  Recent Activity
                </h3>
                <button className="text-gray-400 hover:text-white text-sm self-start sm:self-auto">
                  View All →
                </button>
              </div>

              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-start space-x-3 sm:space-x-4 p-3 sm:p-4 bg-gray-800 rounded-lg">
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-green-500 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-white text-xs">✓</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">
                      New user registration
                    </p>
                    <p className="text-gray-400 text-xs truncate">
                      john.doe@email.com • 2 min ago
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 sm:space-x-4 p-3 sm:p-4 bg-gray-800 rounded-lg">
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-blue-500 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-white text-xs">🔧</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">
                      AI Toolkit accessed
                    </p>
                    <p className="text-gray-400 text-xs">
                      User ID: 2847 • 5 min ago
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 sm:space-x-4 p-3 sm:p-4 bg-gray-800 rounded-lg">
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-purple-500 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-white text-xs">💳</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">
                      Premium upgrade
                    </p>
                    <p className="text-gray-400 text-xs truncate">
                      sarah.wilson@email.com • 12 min ago
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 sm:space-x-4 p-3 sm:p-4 bg-gray-800 rounded-lg">
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-orange-500 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-white text-xs">⚠️</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">
                      System alert resolved
                    </p>
                    <p className="text-gray-400 text-xs">
                      Auto-scaling triggered • 18 min ago
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 sm:space-x-4 p-3 sm:p-4 bg-gray-800 rounded-lg">
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-red-500 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-white text-xs">🎯</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium">
                      Tool usage spike
                    </p>
                    <p className="text-gray-400 text-xs">
                      Midjourney +340% usage • 25 min ago
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions & System Status */}
          <div className="space-y-4 sm:space-y-6 order-1 lg:order-2">
            {/* Quick Actions */}
            <div className="bg-brand-black rounded-xl p-4 sm:p-6">
              <h3 className="text-white text-lg font-bold mb-4">
                Quick Actions
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
                <button className="w-full bg-brand-red hover:bg-red-600 text-white py-2.5 sm:py-3 px-4 rounded-lg text-sm font-medium transition-colors">
                  📧 Send Announcement
                </button>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 sm:py-3 px-4 rounded-lg text-sm font-medium transition-colors">
                  👥 Manage Users
                </button>
                <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2.5 sm:py-3 px-4 rounded-lg text-sm font-medium transition-colors">
                  🛠️ Update Tools
                </button>
                <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2.5 sm:py-3 px-4 rounded-lg text-sm font-medium transition-colors">
                  📊 Generate Report
                </button>
                <button className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2.5 sm:py-3 px-4 rounded-lg text-sm font-medium transition-colors">
                  ⚙️ System Settings
                </button>
              </div>
            </div>

            {/* System Status */}
            <div className="bg-brand-black rounded-xl p-4 sm:p-6">
              <h3 className="text-white text-lg font-bold mb-4">
                System Status
              </h3>
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm">API Server</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-green-400 text-xs">Healthy</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm">Database</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-green-400 text-xs">Optimal</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm">CDN</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                    <span className="text-yellow-400 text-xs">Warning</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm">Email Service</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-green-400 text-xs">Online</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm">Payment Gateway</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-green-400 text-xs">Connected</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Charts Section */}
        <div className="mt-6 sm:mt-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
            {/* User Growth Chart */}
            <div className="bg-brand-black rounded-xl p-4 sm:p-6">
              <h3 className="text-white text-lg font-bold mb-4">
                User Growth (Last 30 Days)
              </h3>
              <div className="bg-gray-800 rounded-lg p-4 h-40 sm:h-48 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl sm:text-6xl mb-2">📈</div>
                  <p className="text-gray-400 text-xs sm:text-sm">
                    Chart visualization would go here
                  </p>
                  <p className="text-white text-base sm:text-lg font-bold mt-2">
                    +847 new users
                  </p>
                </div>
              </div>
            </div>

            {/* Tool Usage Distribution */}
            <div className="bg-brand-black rounded-xl p-4 sm:p-6">
              <h3 className="text-white text-lg font-bold mb-4">
                Most Used Tools
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm truncate mr-2">
                    ChatGPT
                  </span>
                  <div className="flex items-center space-x-2">
                    <div className="bg-gray-800 rounded-full h-2 w-16 sm:w-24">
                      <div
                        className="bg-brand-red h-2 rounded-full"
                        style={{ width: "85%" }}
                      ></div>
                    </div>
                    <span className="text-white text-xs w-8 text-right">
                      85%
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm truncate mr-2">
                    Midjourney
                  </span>
                  <div className="flex items-center space-x-2">
                    <div className="bg-gray-800 rounded-full h-2 w-16 sm:w-24">
                      <div
                        className="bg-blue-500 h-2 rounded-full"
                        style={{ width: "72%" }}
                      ></div>
                    </div>
                    <span className="text-white text-xs w-8 text-right">
                      72%
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm truncate mr-2">
                    GitHub Copilot
                  </span>
                  <div className="flex items-center space-x-2">
                    <div className="bg-gray-800 rounded-full h-2 w-16 sm:w-24">
                      <div
                        className="bg-green-500 h-2 rounded-full"
                        style={{ width: "68%" }}
                      ></div>
                    </div>
                    <span className="text-white text-xs w-8 text-right">
                      68%
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm truncate mr-2">
                    Claude 3.5
                  </span>
                  <div className="flex items-center space-x-2">
                    <div className="bg-gray-800 rounded-full h-2 w-16 sm:w-24">
                      <div
                        className="bg-purple-500 h-2 rounded-full"
                        style={{ width: "56%" }}
                      ></div>
                    </div>
                    <span className="text-white text-xs w-8 text-right">
                      56%
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-gray-300 text-sm truncate mr-2">
                    Runway ML
                  </span>
                  <div className="flex items-center space-x-2">
                    <div className="bg-gray-800 rounded-full h-2 w-16 sm:w-24">
                      <div
                        className="bg-yellow-500 h-2 rounded-full"
                        style={{ width: "43%" }}
                      ></div>
                    </div>
                    <span className="text-white text-xs w-8 text-right">
                      43%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
