import { useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function PromptVault() {
  const [customVision, setCustomVision] = useState("");
  const [selectedKeywords, setSelectedKeywords] = useState<string[]>([]);

  const keywordCategories = {
    Lighting: [
      "golden hour",
      "soft diffused",
      "dramatic rim",
      "neon glow",
      "candlelight",
      "studio lighting",
      "natural light",
      "backlighting",
    ],
    Style: [
      "photorealistic",
      "cinematic",
      "minimalist",
      "vintage",
      "modern",
      "artistic",
      "professional",
      "candid",
    ],
    Camera: [
      "close-up",
      "wide shot",
      "bird's eye",
      "low angle",
      "macro",
      "portrait",
      "landscape",
      "85mm lens",
    ],
    Mood: [
      "dramatic",
      "peaceful",
      "energetic",
      "mysterious",
      "bright",
      "moody",
      "cheerful",
      "elegant",
    ],
  };

  const toggleKeyword = (keyword: string) => {
    setSelectedKeywords((prev) =>
      prev.includes(keyword)
        ? prev.filter((k) => k !== keyword)
        : [...prev, keyword],
    );
  };

  const generatePrompt = () => {
    const parts = [];
    if (customVision.trim()) parts.push(customVision.trim());
    if (selectedKeywords.length > 0) parts.push(selectedKeywords.join(", "));
    return parts.join(". ");
  };

  const copyPrompt = () => {
    const prompt = generatePrompt();
    navigator.clipboard.writeText(prompt);
  };

  return (
    <Layout>
      <div className="container mx-auto px-6 py-12">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-10 h-10 bg-brand-black rounded-lg flex items-center justify-center mr-3">
              <span className="text-white text-lg">🏛️</span>
            </div>
            <h1 className="text-brand-black text-4xl font-black tracking-wide">
              PROMPT VAULT
            </h1>
          </div>
          <p className="text-brand-black text-base font-medium max-w-xl mx-auto">
            Advanced formula builder for perfectly structured AI prompts
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Step 1: Custom Vision */}
          <div className="mb-8">
            <div className="bg-brand-black rounded-xl p-6">
              <h3 className="text-brand-orange text-xl font-bold mb-4">
                Step 1: Describe Your Vision
              </h3>
              <Textarea
                placeholder="Describe your subject, scene, or concept..."
                value={customVision}
                onChange={(e) => setCustomVision(e.target.value)}
                className="bg-gray-800 text-white border-gray-600 min-h-24"
              />
            </div>
          </div>

          {/* Step 2: Keyword Categories */}
          <div className="mb-8">
            <div className="bg-brand-black rounded-xl p-6">
              <h3 className="text-brand-orange text-xl font-bold mb-6">
                Step 2: Select Keywords
              </h3>

              {Object.entries(keywordCategories).map(([category, keywords]) => (
                <div key={category} className="mb-6">
                  <h4 className="text-white text-lg font-semibold mb-3">
                    {category}:
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {keywords.map((keyword) => (
                      <button
                        key={keyword}
                        onClick={() => toggleKeyword(keyword)}
                        className={`px-3 py-1 text-sm rounded-full border transition-colors ${
                          selectedKeywords.includes(keyword)
                            ? "bg-brand-orange text-black border-brand-orange"
                            : "bg-transparent text-white border-gray-500 hover:border-brand-orange"
                        }`}
                      >
                        {keyword}
                        {selectedKeywords.includes(keyword) && (
                          <span className="ml-1">×</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Step 3: Generated Prompt */}
          <div className="mb-8">
            <div className="bg-brand-black rounded-xl p-6">
              <h3 className="text-brand-orange text-xl font-bold mb-4">
                Step 3: Generated Prompt
              </h3>
              <div className="bg-gray-800 p-4 rounded-lg mb-4">
                <p className="text-white text-base leading-relaxed">
                  {generatePrompt() || "Start building your prompt above..."}
                </p>
              </div>
              <div className="flex gap-4">
                <Button
                  onClick={copyPrompt}
                  className="bg-brand-orange text-black hover:bg-brand-orange/90"
                  disabled={!generatePrompt()}
                >
                  📋 Copy Prompt
                </Button>
                <Button
                  onClick={() => {
                    setCustomVision("");
                    setSelectedKeywords([]);
                  }}
                  variant="outline"
                  className="border-gray-500 text-white hover:bg-gray-800"
                >
                  🗑️ Clear All
                </Button>
              </div>
            </div>
          </div>

          {/* Pro Tips */}
          <div className="mb-8">
            <div className="bg-brand-black rounded-xl p-6">
              <h3 className="text-brand-orange text-xl font-bold mb-4">
                Pro Tips
              </h3>
              <ul className="text-white text-base space-y-2">
                <li>
                  • <strong className="text-brand-orange">Structure:</strong>{" "}
                  The vault auto-organizes keywords for optimal AI understanding
                </li>
                <li>
                  • <strong className="text-brand-orange">Keywords:</strong>{" "}
                  Click to add, click × to remove selected keywords
                </li>
                <li>
                  • <strong className="text-brand-orange">Quality:</strong> More
                  specific keywords generally produce better results
                </li>
                <li>
                  • <strong className="text-brand-orange">Iteration:</strong>{" "}
                  Save successful prompts for future reference
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
