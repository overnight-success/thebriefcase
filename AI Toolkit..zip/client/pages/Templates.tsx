import { useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";

export default function Templates() {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const templates = [
    {
      id: "lifestyle-cafe",
      category: "Lifestyle",
      title: "Coffee Shop Scene",
      description: "Perfect for authentic lifestyle photography",
      prompt:
        "Candid lifestyle photo of a young woman in her late 20s sitting at a rustic wooden table in a cozy coffee shop, soft morning light streaming through large windows, she's holding a ceramic mug with both hands, wearing a cream sweater, looking thoughtfully out the window, warm ambient lighting, shot with 85mm lens, shallow depth of field, natural and unposed, Instagram-worthy aesthetic",
      tags: ["lifestyle", "coffee", "portrait", "natural lighting"],
    },
    {
      id: "product-tech",
      category: "Product",
      title: "Tech Product Hero Shot",
      description: "Professional product photography for tech items",
      prompt:
        "Hero product shot of sleek smartphone floating above matte black pedestal, studio lighting setup with key light from right and soft fill from left, minimal tech aesthetic, product displays subtle screen glow, detailed reflections on metallic edges, deep black background with subtle gradient, shot in 4K ultra-sharp detail, commercial photography style",
      tags: ["product", "tech", "studio", "commercial"],
    },
    {
      id: "portrait-dramatic",
      category: "Portrait",
      title: "Dramatic Portrait",
      description: "Cinematic portrait with dramatic lighting",
      prompt:
        "Cinematic portrait of a confident business professional, dramatic side lighting creating strong shadows on half the face, wearing a tailored black suit, looking directly at camera with intense gaze, dark moody background, shot with 85mm lens at f/2.8, professional headshot style, high contrast black and white processing",
      tags: ["portrait", "dramatic", "professional", "cinematic"],
    },
    {
      id: "landscape-golden",
      category: "Landscape",
      title: "Golden Hour Landscape",
      description: "Breathtaking natural scenery",
      prompt:
        "Breathtaking landscape photograph during golden hour, rolling hills covered in wildflowers stretching to the horizon, warm orange and pink sky with wispy clouds, single oak tree silhouetted on hilltop, soft warm light casting long shadows, shot with wide-angle lens, high dynamic range, National Geographic style, serene and peaceful mood",
      tags: ["landscape", "golden hour", "nature", "scenic"],
    },
    {
      id: "food-styling",
      category: "Food",
      title: "Gourmet Food Styling",
      description: "Restaurant-quality food photography",
      prompt:
        "Gourmet food photography of artisanal pasta dish on rustic wooden table, garnished with fresh herbs and parmesan, warm overhead lighting, shallow depth of field focusing on the pasta, rustic table setting with linen napkin and vintage cutlery, food styling magazine quality, appetizing and mouth-watering presentation",
      tags: ["food", "styling", "restaurant", "gourmet"],
    },
    {
      id: "architecture-modern",
      category: "Architecture",
      title: "Modern Building",
      description: "Contemporary architectural photography",
      prompt:
        "Modern architectural photography of sleek glass skyscraper, clean geometric lines and reflective surfaces, shot during blue hour with building lights creating warm glow against cool sky, low angle perspective emphasizing height and grandeur, minimal composition, urban photography style, sharp details throughout",
      tags: ["architecture", "modern", "urban", "geometric"],
    },
  ];

  const categories = [
    "All",
    "Lifestyle",
    "Product",
    "Portrait",
    "Landscape",
    "Food",
    "Architecture",
  ];
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredTemplates =
    selectedCategory === "All"
      ? templates
      : templates.filter((t) => t.category === selectedCategory);

  const copyPrompt = async (prompt: string, id: string) => {
    await navigator.clipboard.writeText(prompt);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <Layout>
      <div className="container mx-auto px-6 py-12">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-10 h-10 bg-brand-black rounded-lg flex items-center justify-center mr-3">
              <span className="text-white text-lg">📋</span>
            </div>
            <h1 className="text-brand-black text-4xl font-black tracking-wide">
              TEMPLATES
            </h1>
          </div>
          <p className="text-brand-black text-base font-medium max-w-xl mx-auto">
            Ready-to-use professional prompts for every creative need
          </p>
        </div>

        {/* Category Filter */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 text-sm font-semibold rounded-full border transition-colors ${
                  selectedCategory === category
                    ? "bg-brand-black text-brand-orange border-brand-black"
                    : "bg-transparent text-brand-black border-brand-black hover:bg-brand-black hover:text-white"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Templates Grid */}
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-6">
            {filteredTemplates.map((template) => (
              <div key={template.id} className="bg-brand-black rounded-xl p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className="bg-brand-orange text-black px-3 py-1 text-xs font-bold rounded-full">
                      {template.category}
                    </span>
                  </div>
                </div>

                <h3 className="text-white text-xl font-bold mb-2">
                  {template.title}
                </h3>

                <p className="text-gray-400 text-sm mb-4">
                  {template.description}
                </p>

                <div className="bg-gray-800 p-4 rounded-lg mb-4">
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {template.prompt}
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-1">
                    {template.tags.map((tag) => (
                      <span
                        key={tag}
                        className="bg-gray-700 text-gray-300 px-2 py-1 text-xs rounded"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <Button
                    onClick={() => copyPrompt(template.prompt, template.id)}
                    className={`text-sm ${
                      copiedId === template.id
                        ? "bg-green-600 hover:bg-green-700"
                        : "bg-brand-orange hover:bg-brand-orange/90"
                    } text-black`}
                  >
                    {copiedId === template.id ? "✓ Copied!" : "📋 Copy"}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Usage Tips */}
        <div className="max-w-4xl mx-auto mt-12">
          <div className="bg-brand-black rounded-xl p-6">
            <h3 className="text-brand-orange text-xl font-bold mb-4">
              How to Use Templates
            </h3>
            <ul className="text-white text-base space-y-2">
              <li>
                •{" "}
                <strong className="text-brand-orange">Copy & Customize:</strong>{" "}
                Use templates as starting points and modify for your needs
              </li>
              <li>
                • <strong className="text-brand-orange">Mix Elements:</strong>{" "}
                Combine parts from different templates for unique results
              </li>
              <li>
                • <strong className="text-brand-orange">Experiment:</strong> Try
                variations by changing lighting, mood, or style keywords
              </li>
              <li>
                • <strong className="text-brand-orange">Save Favorites:</strong>{" "}
                Keep track of templates that work well for your projects
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Layout>
  );
}
