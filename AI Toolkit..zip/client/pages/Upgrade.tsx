import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";

export default function Upgrade() {
  const plans = [
    {
      name: "The Playbook",
      price: "$0.99",
      period: "one-time",
      description: "Essential AI prompting guide for beginners",
      features: [
        "Complete AI image generation guide",
        "50+ proven prompt templates",
        "Beginner to advanced techniques",
        "Style and mood references",
        "Common pitfalls & solutions",
        "Instant digital download",
        "Lifetime access",
      ],
      icon: "📖",
      popular: false,
      cta: "Get Playbook",
      badge: "BEST VALUE",
      badgeColor: "bg-green-500",
    },
    {
      name: "The Briefcase",
      price: "$9.99",
      period: "one-time",
      description: "Curated  premium AI tools and resources",
      features: [
        "Everything in Playbook",
        "80+ AI tools directory",
        "Premium prompt collection",
        "Advanced workflow guides",
        "Commercial usage rights",
        "Bonus video tutorials",
        "Tool comparison charts",
        "Future updates included",
      ],
      icon: "💼",
      popular: true,
      cta: "Get The Briefcase",
      badge: "MOST POPULAR",
      badgeColor: "bg-blue-500",
    },
    {
      name: "Creative O/S System",
      price: "$29",
      period: "one-time",
      description: "Complete AI Creative Operating System",
      features: [
        "Everything in The Briefcase",
        "Advanced automation workflows",
        "Custom AI model training guides",
        "Brand consistency frameworks",

        "Revenue optimization strategies",
        "1-on-1 strategy call",
        "Private community access",
        "White-label licensing rights",
      ],
      icon: "🚀",
      popular: false,
      cta: "Get Creative O/S",
      badge: "PROFESSIONAL",
      badgeColor: "bg-green-500",
    },
  ];

  const benefits = [
    {
      icon: "⚡",
      title: "Instant Access",
      description:
        "Download immediately after purchase - no waiting, no subscriptions",
    },
    {
      icon: "🎨",
      title: "Professional Results",
      description:
        "Create studio-quality content with proven templates and workflows",
    },
    {
      icon: "💰",
      title: "One-Time Payment",
      description: "No recurring fees, no hidden costs - pay once, own forever",
    },
    {
      icon: "🔄",
      title: "Lifetime Updates",
      description:
        "Get all future updates and new content at no additional cost",
    },
    {
      icon: "🛡️",
      title: "Commercial License",
      description: "Use everything for client work and commercial projects",
    },
    {
      icon: "📞",
      title: "Direct Support",
      description: "Get help from our team when you need it most",
    },
  ];

  const testimonials = [
    {
      name: "Alex Morgan",
      role: "Digital Marketing Agency Owner",
      content:
        "The Creative O/S System transformed how we deliver client projects. We're 5x faster and our clients love the results.",
      rating: 5,
    },
    {
      name: "Jessica Liu",
      role: "Freelance Designer",
      content:
        "The Briefcase paid for itself with my first client project. The tool directory alone saved me hours of research.",
      rating: 5,
    },
    {
      name: "Mike Thompson",
      role: "Content Creator",
      content:
        "Started with the Playbook and it completely changed my approach to AI. Simple, effective, and beautifully designed.",
      rating: 5,
    },
  ];

  const faqs = [
    {
      q: "What's the difference between these products?",
      a: "Each product builds on the previous one. The Playbook is perfect for beginners, The Briefcase adds professional tools and resources, and the Creative O/S System includes advanced strategies and personal support for serious creators and agencies.",
    },
    {
      q: "Are these one-time payments?",
      a: "Yes! All products are one-time purchases with lifetime access. No subscriptions, no recurring fees. Pay once, own forever.",
    },
    {
      q: "Do I get updates?",
      a: "Absolutely. All future updates, new content, and improvements are included at no additional cost. You'll always have the latest version.",
    },
    {
      q: "Can I use these commercially?",
      a: "Yes, all products include commercial usage rights. Use the templates, workflows, and generated content for client work and business projects.",
    },
    {
      q: "What if I'm not satisfied?",
      a: "We offer a 30-day money-back guarantee. If you're not completely satisfied, contact us for a full refund - no questions asked.",
    },
  ];

  return (
    <Layout>
      <div className="container mx-auto px-3 sm:px-6 py-5">
        {/* Pricing Plans */}
        <div className="max-w-7xl mx-auto mb-16 sm:mb-20">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`bg-brand-black rounded-xl ${index === 1 ? "p-6 sm:px-8 sm:pt-8 sm:pb-5" : "p-6 sm:p-8"} relative h-full flex flex-col ${
                  plan.popular
                    ? "border-4 border-brand-red transform lg:scale-105 order-first lg:order-none"
                    : "border border-gray-800"
                }`}
              >
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span
                      className={`${plan.badgeColor} text-white px-4 py-2 text-xs sm:text-sm font-bold rounded-full shadow-lg`}
                    >
                      {plan.badge}
                    </span>
                  </div>
                )}

                <div className="text-center mb-6 sm:mb-8">
                  <div className="text-4xl sm:text-5xl mb-4">{plan.icon}</div>
                  <h3 className="text-white text-xl sm:text-2xl font-bold mb-2">
                    {plan.name}
                  </h3>
                  <div className="mb-4">
                    <span className="text-brand-red text-3xl sm:text-4xl font-black">
                      {plan.price}
                    </span>
                    <span className="text-gray-400 text-sm sm:text-lg ml-2">
                      {plan.period}
                    </span>
                  </div>
                  <p className="text-white text-xs font-semibold leading-tight">
                    {plan.description}
                  </p>
                </div>

                <div className="mb-6 sm:mb-8">
                  <h4 className="text-brand-red font-bold mb-4 text-sm sm:text-base">
                    What's included:
                  </h4>
                  <ul className="space-y-2 sm:space-y-3">
                    {plan.features.map((feature, i) => (
                      <li
                        key={i}
                        className="text-gray-300 text-sm flex items-start"
                      >
                        <span className="text-green-400 mr-2 mt-0.5 shrink-0">
                          ✓
                        </span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <Button
                  className={`w-full ${index === 1 ? "py-4 pt-5 pb-4" : "py-3 sm:py-4"} font-bold text-sm sm:text-base transition-all duration-200 mt-auto ${
                    plan.popular
                      ? "bg-brand-red text-white hover:bg-red-600 hover:scale-105"
                      : "bg-transparent border-2 border-brand-red text-brand-red hover:bg-brand-red hover:text-white hover:scale-105"
                  }`}
                >
                  {plan.cta}
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Items */}
        <div className="bg-brand-black rounded-xl p-6 mb-6">
          <h3 className="text-brand-red text-lg font-bold mb-3">
            What's the difference between these products?
          </h3>
          <p className="text-gray-300 leading-relaxed">
            Each product builds on the previous one. The Playbook is perfect for
            beginners, The Briefcase adds professional tools and resources, and
            the Creative O/S System includes advanced strategies and personal
            support for serious creators and agencies.
          </p>
        </div>

        <div className="bg-brand-black rounded-xl p-6 mb-6">
          <h3 className="text-brand-red text-lg font-bold mb-3">
            Are these one-time payments?
          </h3>
          <p className="text-gray-300 leading-relaxed">
            Yes! All products are one-time purchases with lifetime access. No
            subscriptions, no recurring fees. Pay once, own forever.
          </p>
        </div>

        <div className="bg-brand-black rounded-xl p-6 mb-6">
          <h3 className="text-brand-red text-lg font-bold mb-3">
            Do I get updates?
          </h3>
          <p className="text-gray-300 leading-relaxed">
            Absolutely. All future updates, new content, and improvements are
            included at no additional cost. You'll always have the latest
            version.
          </p>
        </div>

        <div className="bg-brand-black rounded-xl p-6 mb-6">
          <h3 className="text-brand-red text-lg font-bold mb-3">
            Can I use these commercially?
          </h3>
          <p className="text-gray-300 leading-relaxed">
            Yes, all products include commercial usage rights. Use the
            templates, workflows, and generated content for client work and
            business projects.
          </p>
        </div>

        <div className="bg-brand-black rounded-xl p-6 mb-20">
          <h3 className="text-brand-red text-lg font-bold mb-3">
            What if I'm not satisfied?
          </h3>
          <p className="text-gray-300 leading-relaxed">
            We offer a 30-day money-back guarantee. If you're not completely
            satisfied, contact us for a full refund - no questions asked.
          </p>
        </div>

        {/* Social Proof */}
        <div className="max-w-6xl mx-auto mb-16 sm:mb-20">
          <div className="text-center mb-8 sm:mb-12"></div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-brand-black rounded-xl p-6">
                <div className="flex mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <span key={i} className="text-yellow-400 text-lg">
                      ⭐
                    </span>
                  ))}
                </div>
                <p className="text-gray-300 text-sm sm:text-base leading-relaxed mb-4">
                  "{testimonial.content}"
                </p>
                <div className="border-t border-gray-700 pt-4">
                  <h4 className="text-white font-bold text-sm sm:text-base">
                    {testimonial.name}
                  </h4>
                  <p className="text-gray-400 text-xs sm:text-sm">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
