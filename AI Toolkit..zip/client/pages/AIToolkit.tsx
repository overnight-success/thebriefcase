import Layout from "@/components/Layout";

export default function AIToolkit() {
  // Function to validate and sanitize links
  const validateAndOpenLink = (url, toolName) => {
    try {
      if (!url) {
        console.error(`No link provided for tool: ${toolName}`);
        return;
      }

      // Ensure URL has protocol
      const validUrl = url.startsWith("http") ? url : `https://${url}`;

      // Open link with security features
      const newWindow = window.open(validUrl, "_blank", "noopener,noreferrer");

      if (!newWindow) {
        console.error(`Popup blocked for: ${validUrl}`);
        // Fallback: try to navigate in current tab
        window.location.href = validUrl;
      }
    } catch (error) {
      console.error(`Failed to open link for ${toolName}:`, url, error);
    }
  };
  const tools = [
    // Development Tools
    {
      name: "GitHub Copilot",
      description: "AI pair programmer for real-time code completion",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Code completion",
        "Real-time suggestions",
        "Multi-language",
      ],
      link: "https://github.com/features/copilot",
    },
    {
      name: "Cursor",
      description: "AI-native code editor with smart suggestions",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "AI code editing",
        "Context awareness",
        "Smart suggestions",
      ],
      link: "https://www.cursor.so",
    },
    {
      name: "Codemi",
      description: "Natural language code writing and debugging assistant",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Natural language coding",
        "Debug assistance",
        "Code explanation",
      ],
      link: "https://codemi.ai",
    },
    {
      name: "Codium",
      description: "Free AI code completion for all major IDEs",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Free",
      pricingColor: "bg-green-500",
      keyFeatures: ["IDE integration", "Code completion", "Multiple languages"],
      link: "https://www.codeium.com",
    },
    {
      name: "Ask Codi",
      description: "Natural language to code generation platform",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Natural language queries",
        "Code generation",
        "Multi-platform",
      ],
      link: "https://www.askcodi.com",
    },
    {
      name: "Askthecode",
      description: "AI assistant for code explanations and debugging",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Code explanations", "Debugging help", "Code analysis"],
      link: "https://askthecode.ai",
    },
    {
      name: "Bito AI",
      description: "Engineering copilot with auto-suggestions and docs",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Auto-suggestions",
        "Documentation generation",
        "Code optimization",
      ],
      link: "https://bito.ai",
    },
    {
      name: "Replit Ghostwriter",
      description: "AI coding assistant integrated into Replit",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Code assistance",
        "Real-time help",
        "Integrated environment",
      ],
      link: "https://replit.com/site/ghostwriter",
    },
    {
      name: "Sweep AI",
      description: "AI tool for codebase maintenance and improvements",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Code maintenance",
        "Automated improvements",
        "Technical debt reduction",
      ],
      link: "https://sweep.dev",
    },
    {
      name: "Phind",
      description: "AI-powered search engine for developers",
      category: "Development",
      categoryColor: "bg-orange-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Developer search", "Code examples", "Technical answers"],
      link: "https://www.phind.com",
    },

    // AI Assistants
    {
      name: "Gemini",
      description: "Google's multimodal LLM for text, image, and code",
      category: "AI Assistant",
      categoryColor: "bg-blue-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Multimodal", "Code understanding", "Text generation"],
      link: "https://gemini.google.com",
    },
    {
      name: "Claude 3.5 Sonnet",
      description: "Advanced language model focused on accuracy and reasoning",
      category: "AI Assistant",
      categoryColor: "bg-blue-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Advanced reasoning", "Long context", "Safety focused"],
      link: "https://claude.ai",
    },
    {
      name: "ChatGPT",
      description: "Industry-standard conversational AI chatbot",
      category: "AI Assistant",
      categoryColor: "bg-blue-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Conversational AI",
        "Wide knowledge base",
        "Creative writing",
      ],
      link: "https://chat.openai.com",
    },
    {
      name: "Perplexity AI",
      description: "AI search engine with citations and real-time data",
      category: "AI Assistant",
      categoryColor: "bg-blue-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Search with citations",
        "Multimodal inputs",
        "Real-time information",
      ],
      link: "https://www.perplexity.ai",
    },
    {
      name: "Grok (X by Elon Musk)",
      description: "Advanced chatbot with image understanding and reasoning",
      category: "AI Assistant",
      categoryColor: "bg-blue-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Image understanding", "PDF parsing", "Advanced reasoning"],
      link: "https://x.com/grok",
    },

    // Web Design
    {
      name: "Framer",
      description: "AI-powered website builder for easy site creation",
      category: "Web Design",
      categoryColor: "bg-orange-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Website builder", "AI design", "No code"],
      link: "https://framer.com",
    },

    // Design Tools
    {
      name: "Figma AI",
      description: "Intelligent design assistant inside Figma",
      category: "Design",
      categoryColor: "bg-pink-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Design assistance", "Auto-layout", "Content generation"],
      link: "https://www.figma.com/blog/introducing-ai-figma",
    },
    {
      name: "Canva Visual Suite",
      description: "AI-enhanced design tools from Canva",
      category: "Design",
      categoryColor: "bg-pink-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["AI design tools", "Template library", "Brand consistency"],
      link: "https://www.canva.com",
    },
    {
      name: "Adobe Firefly",
      description: "Adobe's AI image generation and editing tool",
      category: "Design",
      categoryColor: "bg-pink-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "AI image generation",
        "Creative editing",
        "Adobe integration",
      ],
      link: "https://firefly.adobe.com",
    },
    {
      name: "Adobe Express",
      description: "Simplified Adobe suite with AI features",
      category: "Design",
      categoryColor: "bg-pink-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Quick design", "AI features", "Social media ready"],
      link: "https://express.adobe.com",
    },
    {
      name: "Microsoft Designer",
      description: "AI graphic design tool for social and marketing content",
      category: "Design",
      categoryColor: "bg-pink-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Social media designs",
        "Marketing visuals",
        "AI-powered templates",
      ],
      link: "https://designer.microsoft.com",
    },
    {
      name: "Magic Design",
      description: "AI design assistant that creates layouts from text",
      category: "Design",
      categoryColor: "bg-pink-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Text to design", "Layout generation", "Smart suggestions"],
      link: "https://www.canva.com/magic-design",
    },
    {
      name: "Kittl",
      description: "AI-powered graphic design with templates and vectors",
      category: "Design",
      categoryColor: "bg-pink-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Vector graphics", "Template library", "AI assistance"],
      link: "https://www.kittl.com",
    },

    // Art Generation
    {
      name: "Exactly",
      description: "AI for generating commercial-quality artwork",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Commercial quality",
        "Custom training",
        "Brand consistency",
      ],
      link: "https://www.exactly.ai",
    },
    {
      name: "Dream by Wombo",
      description: "AI app for creating vibrant artwork from text",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Text-to-art", "Multiple styles", "Mobile app"],
      link: "https://www.wombo.art",
    },
    {
      name: "Midjourney",
      description: "Premium AI art generation platform",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["High-quality art", "Style variety", "Discord integration"],
      link: "https://www.midjourney.com",
    },
    {
      name: "Stable Diffusion",
      description: "Open-source AI model for image generation",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free",
      pricingColor: "bg-green-500",
      keyFeatures: ["Open source", "High quality images", "Customizable"],
      link: "https://stability.ai",
    },
    {
      name: "OpenArt",
      description: "AI art generation with prompt library",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Art generation", "Prompt library", "Community features"],
      link: "https://openart.ai",
    },
    {
      name: "NightCafe",
      description: "AI art generator with multiple algorithms",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Multiple algorithms",
        "Community gallery",
        "Style variety",
      ],
      link: "https://creator.nightcafe.studio",
    },
    {
      name: "Playground AI",
      description: "Free AI image generator with collaboration tools",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Image generation",
        "Collaboration tools",
        "Editing features",
      ],
      link: "https://playgroundai.com",
    },
    {
      name: "Leonardo AI",
      description: "AI platform for detailed artwork and game assets",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Game assets", "Detailed artwork", "Custom models"],
      link: "https://leonardo.ai",
    },
    {
      name: "AutoDraw",
      description: "Turns sketches into refined icons and illustrations",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free",
      pricingColor: "bg-green-500",
      keyFeatures: ["Sketch recognition", "Icon generation", "Quick drawings"],
      link: "https://www.autodraw.com",
    },
    {
      name: "Artbreeder",
      description: "Collaborative platform for blending and evolving art",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Image blending",
        "Evolution tools",
        "Collaborative creation",
      ],
      link: "https://www.artbreeder.com",
    },
    {
      name: "Deep Dream",
      description: "Transform images using deep learning for dreamlike effects",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Dreamlike effects",
        "Image transformation",
        "Neural networks",
      ],
      link: "https://deepdreamgenerator.com",
    },
    {
      name: "Hotpot.ai",
      description: "AI tools for image editing and background removal",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Image editing", "Background removal", "Enhancement tools"],
      link: "https://hotpot.ai",
    },
    {
      name: "Imagen & Veo (Google)",
      description: "Google's AI for image and video generation with audio",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Image generation", "Video creation", "Audio support"],
      link: "https://deepmind.google/technologies/imagen-2/",
    },
    {
      name: "LetsEnhance",
      description: "AI-powered image resolution enhancement tool",
      category: "Art Generation",
      categoryColor: "bg-red-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Image upscaling",
        "Resolution enhancement",
        "Photo restoration",
      ],
      link: "https://letsenhance.io",
    },

    // Video & Media
    {
      name: "Descript",
      description: "AI-enhanced video editing with transcription tools",
      category: "Video",
      categoryColor: "bg-purple-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Transcription", "Video editing", "Voice cloning"],
      link: "https://www.descript.com",
    },
    {
      name: "Runway ML",
      description: "Creative AI platform for video and image generation",
      category: "Video",
      categoryColor: "bg-purple-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Video generation", "Creative tools", "AI effects"],
      link: "https://runwayml.com",
    },
    {
      name: "Synthesia",
      description: "AI video avatars with voice cloning capabilities",
      category: "Video",
      categoryColor: "bg-purple-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["AI avatars", "Voice cloning", "Video generation"],
      link: "https://www.synthesia.io",
    },
    {
      name: "Kling AI",
      description:
        "Award-winning AI video generator for quality and affordability",
      category: "Video",
      categoryColor: "bg-purple-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "High-quality video",
        "Affordable pricing",
        "Award-winning",
      ],
      link: "https://kling.ai",
    },

    // Productivity Tools
    {
      name: "DenseDesk",
      description: "Advanced writing assistant with GPT integration",
      category: "Productivity",
      categoryColor: "bg-green-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Writing assistance", "Advanced tuning", "GPT integration"],
      link: "https://www.densedesk.com",
    },
    {
      name: "Booking Agent.io",
      description: "Map-based event booking tool for promoters and artists",
      category: "Productivity",
      categoryColor: "bg-green-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Event booking", "Location mapping", "Artist scheduling"],
      link: "https://booking-agent.io",
    },
    {
      name: "Zapier AI",
      description: "AI automations for workflow optimization",
      category: "Productivity",
      categoryColor: "bg-green-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Workflow automation",
        "AI integrations",
        "App connections",
      ],
      link: "https://zapier.com/blog/best-ai-productivity-tools",
    },
    {
      name: "Taskade",
      description: "AI-powered task visualization and productivity platform",
      category: "Productivity",
      categoryColor: "bg-green-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Task visualization",
        "AI assistance",
        "Team collaboration",
      ],
      link: "https://taskade.com",
    },
    {
      name: "Tome.app",
      description: "AI-enhanced presentation and storytelling platform",
      category: "Productivity",
      categoryColor: "bg-green-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "AI presentations",
        "Storytelling tools",
        "Content generation",
      ],
      link: "https://tome.app",
    },
    {
      name: "NotebooksLM (Google)",
      description: "Research assistant for data analysis and summaries",
      category: "Productivity",
      categoryColor: "bg-green-500",
      pricing: "Free",
      pricingColor: "bg-green-500",
      keyFeatures: [
        "Research assistance",
        "Data analysis",
        "Summary generation",
      ],
      link: "https://notebooklm.google.com",
    },

    // E-commerce
    {
      name: "Booth.ai",
      description: "Professional product photo generation for ecommerce",
      category: "E-commerce",
      categoryColor: "bg-yellow-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Product photography",
        "Shopify integration",
        "Professional quality",
      ],
      link: "https://www.booth.ai",
    },
    {
      name: "Stylized.ai",
      description: "Product photo generation with ecommerce integration",
      category: "E-commerce",
      categoryColor: "bg-yellow-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: [
        "Product styling",
        "E-commerce integration",
        "Photo generation",
      ],
      link: "https://stylized.ai",
    },
    {
      name: "Pebblely",
      description: "AI product image generator with various styles",
      category: "E-commerce",
      categoryColor: "bg-yellow-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Product images", "Style variety", "Setting customization"],
      link: "https://pebblely.com",
    },

    // Writing & Content
    {
      name: "V7 Labs",
      description: "Comprehensive directory of 35+ AI tools",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Free",
      pricingColor: "bg-green-500",
      keyFeatures: ["Tool directory", "Categorized lists", "Writing resources"],
      link: "https://www.v7labs.com/blog/best-ai-tools-listed",
    },
    {
      name: "Resume",
      description: "AI-powered resume and website design generator",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Resume generation",
        "Design templates",
        "Professional formatting",
      ],
      link: "https://www.resume.com",
    },
    {
      name: "Prompt Hunt",
      description: "Prompt gallery and AI art generator platform",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Prompt library", "Art generation", "Community gallery"],
      link: "https://www.prompthunt.com",
    },
    {
      name: "Muzible AI",
      description: "AI for music, documentation, and code assistance",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Music creation", "Documentation", "Code assistance"],
      link: "https://muzible.ai",
    },
    {
      name: "Menou",
      description: "Multimodal AI agent for complex web automation",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Web automation", "Task planning", "Multimodal AI"],
      link: "https://en.menou.org/en/features_52061_openai2",
    },
    {
      name: "Lummi AI",
      description: "AI platform for branded content and marketing assets",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: ["Branded content", "Marketing assets", "Creative tools"],
      link: "https://lummi.ai",
    },
    {
      name: "Headlines",
      description: "GPT-powered copywriting for landing pages and ads",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Premium",
      pricingColor: "bg-blue-500",
      keyFeatures: ["Landing page copy", "Ad copy", "GPT-powered"],
      link: "https://headlines.com",
    },
    {
      name: "GlimAI",
      description: "AI writing assistant and content generation platform",
      category: "Writing",
      categoryColor: "bg-indigo-500",
      pricing: "Free/Premium",
      pricingColor: "bg-purple-500",
      keyFeatures: [
        "Writing assistance",
        "Content generation",
        "Multiple formats",
      ],
      link: "https://glim.ai",
    },
  ];

  // Group tools by category
  const categories = [
    {
      name: "Development Tools",
      description: "AI-powered coding assistants and development platforms",
      icon: "💻",
      color: "bg-orange-500",
      filter: "Development",
    },
    {
      name: "AI Assistants",
      description: "Conversational AI and language models for various tasks",
      icon: "🤖",
      color: "bg-blue-500",
      filter: "AI Assistant",
    },
    {
      name: "Design & Creative",
      description: "Tools for graphic design, UI/UX, and creative workflows",
      icon: "🎨",
      color: "bg-pink-500",
      filter: ["Design", "Web Design"],
    },
    {
      name: "Art Generation",
      description:
        "AI platforms for creating artwork, images, and visual content",
      icon: "🖼️",
      color: "bg-red-500",
      filter: "Art Generation",
    },
    {
      name: "Video & Media",
      description:
        "AI tools for video creation, editing, and multimedia content",
      icon: "🎬",
      color: "bg-purple-500",
      filter: "Video",
    },
    {
      name: "Productivity Tools",
      description: "AI-enhanced tools for workflow automation and productivity",
      icon: "⚡",
      color: "bg-green-500",
      filter: "Productivity",
    },
    {
      name: "E-commerce",
      description: "AI solutions for product photography and online commerce",
      icon: "🛒",
      color: "bg-yellow-500",
      filter: "E-commerce",
    },
    {
      name: "Writing & Content",
      description: "AI writing assistants and content generation platforms",
      icon: "✍️",
      color: "bg-indigo-500",
      filter: "Writing",
    },
  ];

  const getToolsByCategory = (filter) => {
    if (Array.isArray(filter)) {
      return tools.filter((tool) => filter.includes(tool.category));
    }
    return tools.filter((tool) => tool.category === filter);
  };

  return (
    <Layout>
      <div
        className="min-h-screen p-3 sm:p-6"
        style={{ backgroundColor: "#f93920" }}
      >
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8 sm:mb-12">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mr-4">
                <span className="text-white text-2xl">🤖</span>
              </div>
              <div className="text-black text-4xl font-normal tracking-wide leading-10">
                AI TOOLKIT
              </div>
            </div>
          </div>

          {/* Category Sections */}
          {categories.map((category, categoryIndex) => {
            const categoryTools = getToolsByCategory(category.filter);

            if (categoryTools.length === 0) return null;

            return (
              <div key={categoryIndex} className="mb-12 sm:mb-16">
                {/* Category Header */}
                <div className="bg-black rounded-xl p-4 sm:p-6 mb-6">
                  <div className="flex items-center">
                    <div
                      className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center mr-4`}
                    >
                      <span className="text-white text-2xl">
                        {category.icon}
                      </span>
                    </div>
                    <div className="flex-1">
                      <h2 className="text-white text-xl sm:text-2xl font-bold mb-1">
                        {category.name}
                      </h2>
                      <p className="text-gray-400 text-sm sm:text-base">
                        {category.description}
                      </p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`${category.color} text-white px-3 py-1 text-xs font-bold rounded-full`}
                      >
                        {categoryTools.length} tools
                      </span>
                    </div>
                  </div>
                </div>

                {/* Tools Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryTools.map((tool, index) => (
                    <div
                      key={index}
                      className="bg-black rounded-xl p-4 sm:p-5 transition-all duration-200 hover:transform hover:scale-105 cursor-pointer flex flex-col border border-gray-800 min-h-[240px]"
                      onClick={() => validateAndOpenLink(tool.link, tool.name)}
                    >
                      {/* Tool name with tags */}
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="text-white text-lg font-bold leading-tight flex-1 mr-2">
                          {tool.name}
                        </h3>
                        <div className="flex gap-1 shrink-0">
                          <span
                            className={`${tool.categoryColor} text-white text-xs font-bold px-1 py-0.5 rounded text-center`}
                            style={{ fontSize: "10px" }}
                          >
                            {tool.category}
                          </span>
                          <span
                            className={`${tool.pricingColor} text-white text-xs font-bold px-1 py-0.5 rounded text-center`}
                            style={{ fontSize: "10px" }}
                          >
                            {tool.pricing}
                          </span>
                        </div>
                      </div>

                      {/* Description */}
                      <p
                        className="text-gray-400 mb-4 leading-snug truncate"
                        style={{ fontSize: "12px" }}
                      >
                        {tool.description}
                      </p>

                      {/* Key Features */}
                      <div className="mb-4 flex-grow">
                        <h4
                          className="text-sm font-bold mb-2"
                          style={{ color: "#f93920" }}
                        >
                          Key Features:
                        </h4>
                        <ul className="text-gray-400 text-xs space-y-1">
                          {tool.keyFeatures
                            .slice(0, 3)
                            .map((feature, featureIndex) => (
                              <li
                                key={featureIndex}
                                className="flex items-start"
                              >
                                <span className="mr-1.5">•</span>
                                <span>{feature}</span>
                              </li>
                            ))}
                        </ul>
                      </div>

                      {/* Visit Tool Button */}
                      <button
                        className="w-full text-black font-bold py-2 px-4 rounded-lg transition-colors duration-200 text-sm flex items-center justify-center mt-auto"
                        style={{ backgroundColor: "#f93920" }}
                        onMouseEnter={(e) =>
                          (e.target.style.backgroundColor = "#e0321a")
                        }
                        onMouseLeave={(e) =>
                          (e.target.style.backgroundColor = "#f93920")
                        }
                        onClick={(e) => {
                          e.stopPropagation();
                          validateAndOpenLink(tool.link, tool.name);
                        }}
                      >
                        <span className="mr-1.5">🔗</span>
                        Visit Tool
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
