import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Signup() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    useCase: "",
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would normally send the data to your backend
    console.log("Form submitted:", formData);

    // For now, just set submitted state and store in localStorage
    localStorage.setItem("userSignedUp", "true");
    localStorage.setItem("userData", JSON.stringify(formData));
    setIsSubmitted(true);

    // Redirect to main app after 2 seconds
    setTimeout(() => {
      window.location.href = "/ai-toolkit";
    }, 2000);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center p-6">
        <div className="bg-black rounded-2xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🎉</div>
          <h2 className="text-white text-2xl font-bold mb-4">
            Welcome Aboard!
          </h2>
          <p className="text-gray-300 mb-4">
            Thank you for signing up! Redirecting you to the AI Toolkit...
          </p>
          <div className="animate-spin w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full mx-auto"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center p-6">
      <div className="max-w-4xl w-full grid md:grid-cols-2 gap-8 items-center">
        {/* Left Side - Branding */}
        <div className="text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start mb-6">
            <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mr-3">
              <span className="text-white text-xl">🚀</span>
            </div>
            <h1 className="text-white text-4xl font-black tracking-wide">
              AI TOOLKIT
            </h1>
          </div>

          <h2 className="text-white text-3xl font-bold mb-4 leading-tight">
            Unlock the Power of AI Tools
          </h2>

          <p className="text-white/90 text-lg mb-6 leading-relaxed">
            Get instant access to 80+ curated AI tools, step-by-step guides, and
            expert tips to supercharge your creativity and productivity.
          </p>

          <div className="space-y-4 mb-8">
            <div className="flex items-center text-white">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center mr-3">
                <span className="text-orange-500 text-sm">✓</span>
              </div>
              <span>80+ Hand-picked AI tools</span>
            </div>
            <div className="flex items-center text-white">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center mr-3">
                <span className="text-orange-500 text-sm">✓</span>
              </div>
              <span>Easy-to-follow AI basics guide</span>
            </div>
            <div className="flex items-center text-white">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center mr-3">
                <span className="text-orange-500 text-sm">✓</span>
              </div>
              <span>Working links to all tools</span>
            </div>
            <div className="flex items-center text-white">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center mr-3">
                <span className="text-orange-500 text-sm">✓</span>
              </div>
              <span>Instant access - no waiting</span>
            </div>
          </div>

          <div className="text-white/80 text-sm">
            Join thousands of creators, marketers, and entrepreneurs using AI to
            transform their work.
          </div>
        </div>

        {/* Right Side - Signup Form */}
        <div className="bg-black rounded-2xl p-8">
          <div className="text-center mb-6">
            <h3 className="text-white text-2xl font-bold mb-2">
              Get Started Free
            </h3>
            <p className="text-gray-400 text-sm">No credit card required</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="name"
                className="block text-gray-300 text-sm font-medium mb-2"
              >
                Full Name *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                required
                value={formData.name}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-orange-500 focus:outline-none transition-colors"
                placeholder="Enter your full name"
              />
            </div>

            <div>
              <label
                htmlFor="email"
                className="block text-gray-300 text-sm font-medium mb-2"
              >
                Email Address *
              </label>
              <input
                type="email"
                id="email"
                name="email"
                required
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-orange-500 focus:outline-none transition-colors"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label
                htmlFor="company"
                className="block text-gray-300 text-sm font-medium mb-2"
              >
                Company/Organization
              </label>
              <input
                type="text"
                id="company"
                name="company"
                value={formData.company}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-orange-500 focus:outline-none transition-colors"
                placeholder="Your company or freelancer"
              />
            </div>

            <div>
              <label
                htmlFor="useCase"
                className="block text-gray-300 text-sm font-medium mb-2"
              >
                What will you use AI for?
              </label>
              <textarea
                id="useCase"
                name="useCase"
                rows={3}
                value={formData.useCase}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-orange-500 focus:outline-none transition-colors resize-none"
                placeholder="Content creation, design, coding, marketing..."
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600 text-black font-bold py-4 px-6 rounded-lg transition-colors duration-200 text-lg"
            >
              🚀 Get Instant Access
            </Button>
          </form>

          <div className="text-center mt-6 text-gray-400 text-xs">
            By signing up, you agree to receive updates about AI tools and tips.
            Unsubscribe anytime.
          </div>
        </div>
      </div>
    </div>
  );
}
