import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { AppLayout } from "../components/AppLayout";
import { Paywall } from "../components/Paywall";
import { useSubscription } from "../hooks/useSubscription";
import { Bell } from "lucide-react";

export default function Updates() {
  const [showPaywall, setShowPaywall] = useState(false);
  const { subscriptionStatus, canUseFeature, loading } = useSubscription();

  const handleUpgradeRequest = () => {
    setShowPaywall(true);
  };

  const handleUpgradeComplete = () => {
    setShowPaywall(false);
    window.location.reload();
  };

  // Show paywall if needed
  if (showPaywall) {
    const userEmail = localStorage.getItem("userEmail") || "";
    return <Paywall onUpgrade={handleUpgradeComplete} userEmail={userEmail} />;
  }
  const updates = [
    {
      date: "Jan 20, 2025",
      title: "O/S Creative System - Waiting List Now Open",
      type: "New Launch",
      description:
        "Join the waitlist for our revolutionary O/S Creative System - the next generation of AI-powered creative tools",
      isNew: true,
    },
    {
      date: "Jan 20, 2025",
      title: "Get Our Beginners Playbook to AI Creative for Free Here",
      type: "Free Resource",
      description:
        "Download our comprehensive beginner's guide to AI creative tools and start creating professional content today",
      isNew: true,
    },
    {
      date: "Jan 20, 2025",
      title: "Follow Us on Social @overnightsuccessllc",
      type: "Social Update",
      description:
        "Stay connected with the latest tips, tutorials, and creative inspiration by following us on social media",
      isNew: true,
    },
  ];

  return (
    <AppLayout onUpgradeRequest={handleUpgradeRequest}>
      <div className="container mx-auto px-8 py-5">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="p-3 rounded-lg bg-black">
              <Bell className="h-8 w-8 text-neon-orange" />
            </div>
            <h1 className="text-6xl font-black text-black retro-text">
              UPDATES
            </h1>
          </div>
          <p className="text-xl font-bold text-black/80 max-w-2xl mx-auto">
            Stay up-to-date with the latest features, resources, and
            announcements from Overnight Success
          </p>
        </div>

        {/* Updates Feed */}
        <div className="max-w-4xl mx-auto space-y-6">
          {updates.map((update, index) => (
            <Card key={index} className="bg-black border-4 border-black">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Badge className="bg-neon-orange text-black font-bold text-xs">
                        {update.type}
                      </Badge>
                      {update.isNew && (
                        <Badge className="bg-green-600 text-white font-bold text-xs animate-pulse">
                          NEW
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-2xl font-black text-cream mb-2">
                      {update.title}
                    </CardTitle>
                    <p className="text-sm text-cream/60 font-bold">
                      {update.date}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-cream font-medium leading-relaxed">
                  {update.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
